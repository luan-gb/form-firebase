/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

// this is used in /site/index.html
// Note: implement when we decide to add stuff to home page
